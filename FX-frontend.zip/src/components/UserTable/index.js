export { default } from './UserTable';
