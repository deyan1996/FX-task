import { styled } from "@mui/material/styles";

const CustomFlexBox = styled("div")({
  display: "flex",
});

export default CustomFlexBox;
