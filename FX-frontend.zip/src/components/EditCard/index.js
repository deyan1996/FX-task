export { default } from "./EditCard";
